//
//  second view.swift
//  Podcasts
//
//  Created by Shaima Alharbi on 14/01/1445 AH.
//

import Foundation
struct SecondView: view {
    var body: some view {
        Text("Hello, am second view!")
    }
}

struct SecondView_Previews: PreviewProvider {
    static var previews: some view {
        SecondView()
    }
}
