//
//  PodcastsApp.swift
//  Podcasts
//
//  Created by Shaima Alharbi on 14/01/1445 AH.
//

import SwiftUI

@main
struct PodcastsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
