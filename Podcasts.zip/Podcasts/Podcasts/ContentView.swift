//
//  ContentView.swift
//  Podcasts
//
//  Created by Shaima Alharbi on 14/01/1445 AH.
//

import SwiftUI

struct DataCard : Identifiable  {
    var id: UUID = UUID()
    let title : String
    let subtitle : String
    let price : Int
    let imageName :String

}
struct ContentView: View {
    let categories : Array<String> = [
        "Education" ,
        " Society ",
        " Health",
        "Comedy"
    ]
    let cards : Array<DataCard> =
    Array(
        repeating: DataCard(title: "Title1",
                            subtitle: "Description",
                            price: 10 ,
                            imageName: ""),
        count: 5
    )
    
    var body: some View {
        
        NavigationStack{
            //Title
            
            VStack {
                Text("Podcasts")
                    .font(.system(.largeTitle))
                // Search box
                HStack {
                    Image(systemName:"magnifyingglass")
                    TextField("Search", text: .constant("Search"))
                        .frame(height: 40)
                        .foregroundColor(Color.gray)
                }
                .background(Color.gray .opacity(0.40))
                .cornerRadius(8)
                
                Spacer()
                    .frame(height: 30)
                
                ScrollView(.horizontal){
                    HStack{
                        ForEach(categories, id: \.self) {category in
                            Button(
                                action: {
                                },
                                label: {
                                    Text(category)
                                        .padding(.vertical, 8)
                                        .padding(.horizontal, 16)
                                        .background(Color.gray .opacity(0.60))
                                        .foregroundColor(Color.black)
                                })
                            .cornerRadius(8)
                        }
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                
                Spacer()
                    .frame(height: 10)
                
                //handling card
                ZStack {
                    Rectangle()
                        .fill(Color.black .opacity(0.1))
                        .background(
                            Image("image22").resizable())
              
                    .frame(height: 190)
                }
                .frame(height : 200)
                .cornerRadius(8)
                
                Spacer()
                    .frame(height: 30)
                
                //Popular Cards
                HStack {
                    Text("Top Show")
                    Spacer()
                    NavigationLink{
                    }
                label: {
                    Text("See All >")
                }
                }
                
                ScrollView(.horizontal){
                    HStack{
                        ForEach(cards){
                            card in ZStack {
                                Rectangle()
                                    .fill(Color.black .opacity(0.1))
                                VStack {
                                    Spacer()
                                    Text(card.title)
                                        .frame(maxWidth:
                                                .infinity ,
                                               alignment:
                                                .leading )
                                    HStack {
                                        Text(card.subtitle)
                                        Spacer()
                                        Text(card.price.description)
                                    }
                                }
                                .frame(width: 250, height: 140)
                                .colorInvert()
                            }
                            .frame(width: 270 ,  height : 150)
                            .background(Image("image22").resizable())
                            .cornerRadius(8)
                        }
                    }
                }
                Spacer()
            }
            .frame(maxWidth: 365,
                   alignment: .leading )
        }}
    
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            ContentView()
                .preferredColorScheme(.dark)

        }
    }
}
